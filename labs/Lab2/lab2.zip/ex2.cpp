/*
 * Lab2 Ex2 VE280 20SU
 * Created by: Yiqing Fan
 * Last update: May 25, 2020
 */

#include <cstdlib>
#include <iostream>

using namespace std;

typedef struct {
    // TODO: complete struct
} Student;

int compare(const void* p1, const void* p2) {
    // TODO: complete compare function for qsort()
}

int main() {
    // TODO: read input

    // TODO: sort array with qsort()

    // TODO: print result

    return 0;
}